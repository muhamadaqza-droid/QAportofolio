import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

public class TugasModul9 {

    WebDriver driver;

    @Test(testName = "Positive Login Test")

    public void loginTest(){
        //open browser
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().minimize();
        driver.get("https://katalon-demo-cura.herokuapp.com/");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        //login
        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[normalize-space()='CURA Healthcare Service']"))));
        driver.findElement(By.xpath("//a[@id='btn-make-appointment']")).click();
        driver.findElement(By.xpath("//input[@id='txt-username']")).sendKeys("John Doe");
        driver.findElement(By.xpath("//input[@id='txt-password']")).sendKeys("ThisIsNotAPassword");
        driver.findElement(By.xpath("//button[@id='btn-login']")).click();

        //verifikasi
        String actualText = driver.findElement(By.xpath("//h2[normalize-space()='Make Appointment']")).getText();
        System.out.println("Actual Text = "+actualText);
        String expectedText = "Make Appointment";

        Assert.assertEquals(actualText,expectedText);

        driver.quit();
    }
}