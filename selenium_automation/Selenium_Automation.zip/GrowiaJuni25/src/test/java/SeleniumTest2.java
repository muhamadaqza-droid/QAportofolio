import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

public class SeleniumTest2 {

    WebDriver driver;

    @Test(testName = "Positive Login Test")

    public void loginTest(){
        //open browser
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().minimize();
        driver.get("https://the-internet.herokuapp.com/login");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        //input username
        wait.until((ExpectedConditions.visibilityOfElementLocated(By.id("username"))));
        driver.findElement(By.name("username")).sendKeys("tomsmith");
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys("SuperSecretPassword!");
        driver.findElement(By.xpath("//button[@type='submit']")).click();

        //verify berhasil login
        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[normalize-space()='Secure Area']"))));
        String txtSecureAreaActual = driver.findElement(By.xpath("//h2[normalize-space()='Secure Area']")).getText();
        String txtSecureAreaExpected = "Secure Area";

        Assert.assertEquals(txtSecureAreaActual,txtSecureAreaExpected);

        //close browser
        driver.quit();
    }
}
